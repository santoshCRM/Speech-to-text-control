﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpeechToText
{
    public class CreateNote : CodeActivity
    {
        [Input("LogicalName")]
        [RequiredArgument]
        public InArgument<string> LogicalName { get; set; }

        [Input("recordId")]
        [RequiredArgument]
        public InArgument<string> recordId { get; set; }


        [Input("note")]
        [RequiredArgument]
        public InArgument<string> note { get; set; }


        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService traceService = executionContext.GetExtension<ITracingService>();
            try
            {

                IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                traceService.Trace("Workflow Started");
                if (service != null && LogicalName.Get(executionContext) != null
                    && recordId.Get(executionContext) != null && note.Get(executionContext) != null)
                {
                    traceService.Trace("Creation Started");
                    EntityReference regardingEntity = new EntityReference(LogicalName.Get(executionContext), new Guid(recordId.Get(executionContext)));
                    Entity TargetEntity = new Entity("annotation");
                    TargetEntity.Attributes["objectid"] = regardingEntity;
                    TargetEntity.Attributes["notetext"] = note.Get(executionContext);
                    service.Create(TargetEntity);
                    traceService.Trace("Ended Started");
                }
                // throw new InvalidPluginExecutionException("test");
            }
            catch (Exception ex)
            {
                traceService.Trace("Error occured: " + ex.ToString());
                throw new InvalidPluginExecutionException("test");

            }

        }
    }
}
